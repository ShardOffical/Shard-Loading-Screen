Config = {}

-- Server Info
Config.ServerName = "My Server"
Config.Discord = "discord.gg/example"
Config.AccentColor = "#ff0055"

-- Media
Config.BackgroundVideo = "background.mp4"
Config.Logo = "logo.png"
Config.Music = "music.mp3"

-- Staff List
Config.Staff = {
    {name = "Alice", role = "Owner", img = "staff1.png"},
    {name = "Bob", role = "Admin", img = "staff2.png"},
    {name = "Charlie", role = "Moderator", img = "staff3.png"}
}
