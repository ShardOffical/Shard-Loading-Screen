fx_version 'cerulean'
game 'gta5'

author 'Shard'
description 'Modern FiveM Loading Screen'
version '1.0.8'

shared_script 'config.lua'

loadscreen 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/assets/*.png',
    'html/assets/*.mp4',
    'html/assets/*.mp3',
    'html/assets/*.ttf'
}
