// Load config from Lua (will be injected by shared_script)
const Config = {
    AccentColor: "#ff0055",
    BackgroundVideo: "background.mp4",
    Logo: "logo.png",
    ServerName: "My Server",
    Discord: "discord.gg/example",
    Music: "music.mp3",
    Staff: [
        {name:"Alice", role:"Owner", img:"staff1.png"},
        {name:"Bob", role:"Admin", img:"staff2.png"},
        {name:"Charlie", role:"Moderator", img:"staff3.png"}
    ]
};

window.addEventListener('DOMContentLoaded', () => {
    document.documentElement.style.setProperty("--accent", Config.AccentColor);

    // Media
    const bgVideo = document.getElementById("bg-video");
    bgVideo.src = `assets/${Config.BackgroundVideo}`;

    const logo = document.getElementById("logo");
    logo.src = `assets/${Config.Logo}`;

    document.getElementById("server-name").textContent = Config.ServerName;
    document.getElementById("discord").textContent = Config.Discord;

    // Music
    const music = document.getElementById("bg-music");
    music.src = `assets/${Config.Music}`;
    music.volume = 0.4;
    music.play().catch(() => {
        document.body.addEventListener("click", () => music.play(), { once: true });
    });

    // Staff panel
    const staffList = document.getElementById("staff-list");
    Config.Staff.forEach(member => {
        const div = document.createElement("div");
        div.classList.add("staff-member");
        div.innerHTML = `
            <img src="assets/${member.img}" alt="${member.name}">
            <div class="staff-info">
                <span>${member.name}</span>
                <small>${member.role}</small>
            </div>
        `;
        staffList.appendChild(div);
    });
});
